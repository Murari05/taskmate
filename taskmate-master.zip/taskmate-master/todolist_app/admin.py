from django.contrib import admin
from todolist_app.models import TasksList

# Register your models here.


admin.site.register(TasksList)