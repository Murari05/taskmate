from django.apps import AppConfig


class TodolistAppConfig(AppConfig):
    name = 'todolist_app'
